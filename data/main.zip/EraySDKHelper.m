//
//  EraySDKHelper.m
//  HelloCocos
//
//  Created by sloppy on 16/10/10.
//
//

#import "EraySDKHelper.h"
#import "MBProgressHUD.h"
#import "ErayPayInfo.h"

#define ECPURCHASE_TEST_SERVER // 本地测试，是否是泥沙盒环境

#define USE_SERVER_VERIFY // 是否用服务端进行校验

#ifdef ECPURCHASE_TEST_SERVER
#define VAILDATING_RECEIPTS_URL @"https://sandbox.itunes.apple.com/verifyReceipt"
#else
#define VAILDATING_RECEIPTS_URL @"https://buy.itunes.apple.com/verifyReceipt"
#endif



static EraySDKHelper *instance = nil;
static MBProgressHUD *_HUD = nil;
@implementation EraySDKHelper
+(EraySDKHelper *)getInstance {
    if (instance == nil) {
        instance = [[self alloc] init];
    }
    return instance;
}
-(void)initialize:(NSString*)verifyURL delegate:(id <EraySDKDelegate>)delegate{
    if(_isInit){
        return;
    }
    _verifyUrl = [[NSString alloc] initWithString:verifyURL];
    _delegate = delegate;
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    //[[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
}

-(void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray<SKPaymentTransaction *> *)transactions{
    for (SKPaymentTransaction *transaction in transactions) {
        switch (transaction.transactionState) {
            case SKPaymentTransactionStatePurchased:
                NSLog(@"交易完成");
                [self completeTransaction:transaction];
                [_HUD hide:YES];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                [_HUD hide:YES];
                NSLog(@"交易失败");
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                NSLog(@"交易Restored");
                break;
            case SKPaymentTransactionStatePurchasing:
                NSLog(@"商品添加进购买列表中");
                break;
            default:
                [_HUD hide:YES];
                break;
        }
    }
    NSLog(@"交易回调");
}

-(void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue{
    NSLog(@"购买队列完成");
}

-(void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error{
    NSLog(@"购买恢复出错");
}

-(void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response{
    NSArray *list = response.products;
    if(list.count==0){
        NSLog(@"no product");
        return;
    }
    for(SKProduct *product in list){
        NSLog(@"product info");
        NSLog(@"SKProduct 描述信息%@", [product description]);
        NSLog(@"产品标题 %@" , product.localizedTitle);
        NSLog(@"产品描述信息: %@" , product.localizedDescription);
        NSLog(@"价格: %@" , product.price);
        NSLog(@"Product id: %@" , product.productIdentifier);
    }
    SKPayment* payment=[SKPayment paymentWithProduct:[list objectAtIndex:0]];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

-(void)pay{
    if(!_isInit){
        NSLog(@"not initialize");
    }
    UIWindow *win = [UIApplication sharedApplication].keyWindow;
    _HUD = [MBProgressHUD showHUDAddedTo:win animated:YES];
    _HUD.mode = MBProgressHUDModeIndeterminate;
    _HUD.color = [UIColor colorWithRed:0.23 green:0.50 blue:0.82 alpha:0.90];
    _HUD.labelText = @"充值中";
    _HUD.margin = 10.f;
    _HUD.removeFromSuperViewOnHide = YES;

    NSLog(@"start pay:%@",[ErayPayInfo getInstance].productId);
    if([SKPaymentQueue canMakePayments]){
        //[[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
        [self getProductInfo:[ErayPayInfo getInstance].productId];
    }else{
        NSLog(@"can not buy");
    }
}
-(void)getProductInfo:(NSString*)productId{
    NSSet* set = [NSSet setWithArray:@[productId]];
    SKProductsRequest* request = [[SKProductsRequest alloc] initWithProductIdentifiers:set];
    request.delegate = self;
    [request start];
}

-(void)completeTransaction:(SKPaymentTransaction*)transaction{
    [self verifyTransaction:transaction];
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    if(_delegate!=nil){
        [_delegate onPayResult:ERAY_SDK_PAY_SUCCESS];
    }
}

-(void)failedTransaction:(SKPaymentTransaction*)transaction{
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    if(_delegate!=nil){
        [_delegate onPayResult:ERAY_SDK_PAY_FAILED];
    }
}

-(void)restoreTransaction:(SKPaymentTransaction*)transaction{
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
}

-(void)verifyTransaction:(SKPaymentTransaction*)transaction{
#ifdef USE_SERVER_VERIFY
    NSString *transactionIdentifier = transaction.transactionIdentifier;
    NSLog(@"transactionIdentifier:%@", transactionIdentifier);
    NSURL *urlForValidation = [NSURL URLWithString:_verifyUrl];
    NSMutableURLRequest *validationRequest = [[NSMutableURLRequest alloc] initWithURL:urlForValidation];
    [validationRequest setHTTPMethod:@"POST"];
    NSString *strTest = [NSString stringWithFormat:@"receipt=%@", [transaction.transactionReceipt base64Encoding]];
    [validationRequest setHTTPBody:[strTest dataUsingEncoding:NSUTF8StringEncoding]];
    NSData *responseData = [NSURLConnection sendSynchronousRequest:validationRequest returningResponse:nil error:nil];
    NSString *response = [[NSString alloc] initWithData: responseData encoding: NSUTF8StringEncoding];
    NSLog(@"%@", response);
#else
    NSString *transactionIdentifier = transaction.transactionIdentifier;
    NSData * transactionReceipt = transaction.transactionReceipt;
    
    NSString *payload = [NSString stringWithFormat:@"{\"receipt-data\":\"%@\",\"password\":\"%@\"}",[transactionReceipt base64Encoding],transactionIdentifier];
    NSData *payloadData = [payload dataUsingEncoding:NSUTF8StringEncoding];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:VAILDATING_RECEIPTS_URL]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:payloadData];
    NSError* err;
    NSURLResponse *theResponse = nil;
    NSData *data=[NSURLConnection sendSynchronousRequest:request returningResponse:&theResponse error:&err];
    NSError *jsonParsingError = nil;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&jsonParsingError];
    NSLog(@"dic:%@", dict);
#endif
}
@end
