//
//  EraySDKHelper.h
//  HelloCocos
//
//  Created by sloppy on 16/10/10.
//
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

typedef enum {
    ERAY_SDK_PAY_SUCCESS=0,
    ERAY_SDK_PAY_FAILED,
} EraySDKCode;

@protocol EraySDKDelegate
@required
- (void)onPayResult:(EraySDKCode)code;
@optional
- (void)onPayRestore:(EraySDKCode)code;
@end

@interface EraySDKHelper : NSObject<SKProductsRequestDelegate,SKPaymentTransactionObserver>
{
    NSString *_verifyUrl;
    BOOL _isInit;
}
@property(nonatomic, assign) id<EraySDKDelegate> delegate;
/**
 * @brief 充值接口，在充值前，请设置ErayPayInfo单例的相关信息
 */
-(void)pay;

+(EraySDKHelper *)getInstance;
/**
 * 初始化SDK
 */
-(void)initialize:(NSString*)verifyURL delegate:(id <EraySDKDelegate>)delegate;

-(void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray<SKPaymentTransaction *> *)transactions;

-(void)paymentQueueRestoreCompletedTransactionsFinished:(SKPaymentQueue *)queue;

-(void)paymentQueue:(SKPaymentQueue *)queue restoreCompletedTransactionsFailedWithError:(NSError *)error;

-(void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response;

-(void)getProductInfo:(NSString*)productId;

-(void)completeTransaction:(SKPaymentTransaction*)transaction;

-(void)failedTransaction:(SKPaymentTransaction*)transaction;

-(void)restoreTransaction:(SKPaymentTransaction*)transaction;

-(void)verifyTransaction:(SKPaymentTransaction*)transaction;
@end
