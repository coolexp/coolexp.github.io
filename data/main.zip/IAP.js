var http = require("http");            //提供web服务  
var url = require("url");            //解析GET请求  
var query = require("querystring");    //解析POST请求
var https = require("https");   

//服务
var server = function(request,response){  
    //定义报文头
    response.writeHead(200,{"Content-Type":"text/json"});
    //判断是GET/POST请求
    if(request.method == "GET"){
        callbackPayServer("",true);
        var params = [];
        params = url.parse(request.url,true).query;
        params['fruit'] = compute(params);
        response.write(JSON.stringify(params));
        response.end();
       
    }else{
        var postdata = "";
        request.addListener("data",function(postchunk){
            postdata += postchunk;
        })

        //POST结束输出结果
        request.addListener("end",function(){
            var params = query.parse(postdata);
            params['fruit'] = compute(params);
            //response.write(JSON.stringify(params));
            //response.end();
            console.log("Json:"+params['json']);
            verifyReceipt(params['receipt'],function(data){
                var json = JSON.parse(data);
                if(json["status"]==0){
                  response.write('{"code":0,"msg":"Success"}');
                  if(params['json']){
                      callbackPayServer(params['json'],false);
                  }
                }else{
                  response.write(data);
                }
                response.end();
            },true);// 如果是正式的，请修改成false
        })
    }

};

//计算
var compute = function(params){  
    switch(params['type']){
        case "add": return parseFloat(params['num']) + parseFloat(params['num1']);break;
        case "subtract": return parseFloat(params['num']) - parseFloat(params['num1']);break;
        case "multiplication": return parseFloat(params['num']) * parseFloat(params['num1']);break;
        case "division": return parseFloat(params['num']) / parseFloat(params['num1']);break;
    }
};
// 跟苹果服务充值服务器进行检验
var verifyReceipt = function(receiptData, responder,inReview){
  var receiptEnvelope = {"receipt-data": receiptData};
  var receiptEnvelopeStr = JSON.stringify(receiptEnvelope);
  var options = {
      host: inReview?'sandbox.itunes.apple.com':'buy.itunes.apple.com',
      port: 443,
      path: '/verifyReceipt',
      method: 'POST',
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(receiptEnvelopeStr)
      }
  };

  var req = https.request(options, function(res) {
      var _data='';
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          _data += chunk;
      });
      res.on('end', function () {
          console.log("body: " + _data);
          responder(_data);
      });
  });

  req.write(receiptEnvelopeStr);
  req.end();
};
// 通知充值回调，告诉充值成功
var callbackPayServer = function(json,isFix){
  console.log("callbackPayServer");
  var extra = {"UserId":"3000200004","ChargeId":"2","TargetId":"0"};
  var data = {
    "account":"s0001",
    "amount":"30",
    "channel":"1",
    "extra":JSON.stringify(extra),
    "game_id":"1",
    "openid":"s0001",
    "order_id":Number(new Date()),
    "product_id":"com.gaint.eray.mszj.diamond2",
    "time":"1333",
    "transaction_id":"11",
    "version":"1.0",
    "zone_id":"30002",
    "sign":"111"
  };
  if(!isFix){
    var jsObj = JSON.parse(json);
    data["account"]= jsObj["accountName"];
    data["openid"]= jsObj["accountName"];
    data["amount"]= parseInt(jsObj["money"])/100;
    data["extra"]= jsObj["optionalData"];
    data["zone_id"]= jsObj["serverId"];
    data["product_id"]= jsObj["productId"];
  }
  var content = query.stringify(data);
  console.log("content:"+content);
  var options = {
      host: '118.194.48.43',
      port: 8010,
      path: '/giantChargeRs?'+content,
      method: 'GET'
  };
  var req = http.request(options, function(res) {
      var _data='';
      res.setEncoding('utf8');
      res.on('data', function (chunk) {
          _data += chunk;
      });
      res.on('end', function () {
          console.log("body: " + _data);
      });
      res.on('error', function (error) {
          console.log("error: " + error);
      });
  });
 
  req.end();
};

//开启服务在127.0.0.1:8080
http.createServer(server).listen(8080);  
console.log("Server start!");  