require 'xcodeproj'
require 'pathname'
require 'inifile'
require 'fileutils'

def init()
    path = File.dirname(__FILE__)
    $LOCAL_PATH = Pathname.new("../#{path}").realpath.to_s # 获取脚本当前目录全路径
    file = IniFile.load("#{path}/config.ini")
    config = file["ProjectInfo"]
    $PROJECT_TEMPLATE_PATH = "#{path}/#{config['Template_File']}" # 工程的原始文件
    $PROJECT_PATH = "#{$LOCAL_PATH}/#{config['Target_File']}" # 工程的原始文件
    $TARGET_NAME="#{config['Target_Name']}"

    $SOURCE_FOLDER_NAME = "Classes" # 代码目录
    $NOT_INCLUDE_FILES=[".DS_Store","android","Android","linux","win"] # 过滤不需要添加进工程的文件，文件夹  
    $CLASS_PATH = $LOCAL_PATH+"/"+$SOURCE_FOLDER_NAME

    FileUtils.rm_rf("#{$PROJECT_PATH}")
    FileUtils.cp_r("#{$PROJECT_TEMPLATE_PATH}","#{$PROJECT_PATH}")
end

def generateSubGroup(target,group,path,folder,prefix)
    subGroup = group.find_subpath(File.join(folder), true)
    Dir.entries(path).each do |sub|         
        if sub != '.' && sub != '..'
            if $NOT_INCLUDE_FILES.index(sub)==nil
              if File.directory?("#{path}/#{sub}")
                generateSubGroup(target,subGroup,"#{path}/#{sub}","#{sub}","#{prefix}/#{sub}")
              else
                file_ref = subGroup.new_reference("#{prefix}/#{sub}")
                target.add_file_references([file_ref]) 
              end  
            end
        end  
  end
end

def generateProject()
    init()#初始化一些变量
    project = Xcodeproj::Project.open($PROJECT_PATH)
    project.targets.each do |target|
      if target.name==$TARGET_NAME
          group = project.main_group
          group.set_source_tree('SOURCE_ROOT')
          #get_file_list(CLASS_PATH)
          generateSubGroup(target,group,$CLASS_PATH,"#{$SOURCE_FOLDER_NAME}","../#{$SOURCE_FOLDER_NAME}/")
          #sdkGroup = group.find_subpath(File.join('sdk','ios'), true)
          #file_ref = sdkGroup.new_reference("../Classes/sdk/SDK.cpp")
          #file_ref = sdkGroup.new_reference("../Classes/sdk/SDK.hpp")
          #target.add_file_references([file_ref]) 
      end
    end
    project.save()
end
generateProject()