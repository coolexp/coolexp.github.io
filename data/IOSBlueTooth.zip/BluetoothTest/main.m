//
//  main.m
//  BluetoothTest
//
//  Created by 刘奥明 on 16/4/12.
//  Copyright © 2016年 liuting. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
