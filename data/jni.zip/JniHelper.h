#pragma once
#include <jni.h>

typedef struct JniMethodInfo_
{
    JNIEnv *    env;
    jclass      classID;
    jmethodID   methodID;
} JniMethodInfo;
class JniHelper{
public:
	static void setJavaVM(JavaVM *vm);
	static JNIEnv* getEnv();
	static bool getStaticMethodInfo(JniMethodInfo &methodinfo, const char *className, const char *methodName,const char *paramCode);
private:
	static JavaVM *pvm;
};