#include "JniHelper.h"
#include <android/log.h>


#define  LOG_TAG    "JniHelper"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

JavaVM* JniHelper::pvm=nullptr;

void JniHelper::setJavaVM(JavaVM *vm){
	pvm = vm;
}

JNIEnv* JniHelper::getEnv(){
	JNIEnv*  env=nullptr;
    pvm->GetEnv((void**)&env,JNI_VERSION_1_4);
    return env;
}

 bool JniHelper::getStaticMethodInfo(JniMethodInfo &methodinfo, const char *className,const char *methodName, const char *paramCode) {
        if ((nullptr == className) ||
            (nullptr == methodName) ||
            (nullptr == paramCode)) {
            return false;
        }

        JNIEnv *env = JniHelper::getEnv();
        if (!env) {
            LOGE("Failed to get JNIEnv");
            return false;
        }
            
        jclass classID = env->FindClass(className);
        if (! classID) {
            LOGE("Failed to find class %s", className);
            env->ExceptionClear();
            return false;
        }

        jmethodID methodID = env->GetStaticMethodID(classID, methodName, paramCode);
        if (! methodID) {
            LOGE("Failed to find static method id of %s", methodName);
            env->ExceptionClear();
            return false;
        }
            
        methodinfo.classID = classID;
        methodinfo.env = env;
        methodinfo.methodID = methodID;
        return true;
    }