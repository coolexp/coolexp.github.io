package com.example.android.bluetoothchat;
import java.util.HashMap;

/**
 * This class includes a small subset of standard GATT attributes for demonstration purposes.
 */
public class SampleGattAttributes {
    private static HashMap<String, String> attributes = new HashMap();
    public static String HEART_RATE_MEASUREMENT = "D5DC3450-27EF-4C3F-94D3-1F4AB15631FF";
    public static String CLIENT_CHARACTERISTIC_CONFIG = "6A3D4B29-123D-4F2A-12A8-D5E211411402";
    public static String DES_CONFIG_IOS_0 = "00002900-0000-1000-8000-00805f9b34fb";//"Heart Rate Service"
    public static String DES_CONFIG_IOS_1 = "00002901-0000-1000-8000-00805f9b34fb";//"Device Information Service"
    public static String DES_CONFIG_IOS_2 = "00002902-0000-1000-8000-00805f9b34fb";//Manufacturer Name String


    public static String lookup(String uuid, String defaultName) {
        String name = attributes.get(uuid);
        return name == null ? defaultName : name;
    }
}

