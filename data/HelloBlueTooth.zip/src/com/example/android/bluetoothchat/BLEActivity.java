package com.example.android.bluetoothchat;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
@SuppressLint("NewApi")
public class BLEActivity extends Activity implements  OnClickListener{
	private BluetoothAdapter mBluetoothAdapter;
	private static final long SCAN_PERIOD = 10000;
	private boolean mScanning;
	private Handler mHandler;
    private BluetoothLeService mBluetoothLeService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble);
        Button supportBTN=(Button)this.findViewById(R.id.SupportBLE);
        Button writeDataBtn=(Button)this.findViewById(R.id.WriteData);
        if(supportBTN!=null){
        	supportBTN.setOnClickListener(this);
        }
        if(writeDataBtn!=null){
        	writeDataBtn.setOnClickListener(this);
        }
	}
	public void onClick(View v) {
		switch(v.getId()){
			case R.id.SupportBLE:
			{
				initBLE();
				break;
			}
			case R.id.WriteData:
			{
				writeValue();
				break;
			}
			default:{
				break;
			}
		}
	}
	private void writeValue(){
		if(mCharacteristic!=null){
			String value = "Hello";
			byte[] bytes = null;
			try {
				bytes = value.getBytes("UTF8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(bytes!=null){
				mBluetoothLeService.writeValueData(mCharacteristic, bytes);
			}
		}
	}
	
	private void initBLE(){
		mHandler = new Handler();
		final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
		mBluetoothAdapter = bluetoothManager.getAdapter();
		if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){
			 Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
		}
		scanLeDevice(true);
	}
	private BluetoothAdapter.LeScanCallback mLeScanCallback =
	        new BluetoothAdapter.LeScanCallback() {
	    @Override
	    public void onLeScan(final BluetoothDevice device, int rssi,byte[] scanRecord) {
		        runOnUiThread(new Runnable() {
		           @Override
		           public void run() {
		        	   final String deviceName = device.getName();
		        	   final String deviceAdd = device.getAddress();
		        	   Log.d("BLE", deviceName);
		        	   Log.d("BLE", deviceAdd);
		        	   if(deviceName.equalsIgnoreCase("iPhone 5s")){
		        		   mDeviceAddress = deviceAdd;
		        		   startConnect();
		        	   }
		           }
	       });
	   }
	};
	// Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e("BLE", "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };
    private String mDeviceAddress;

	private void startConnect(){
		scanLeDevice(false);
		Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
		bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
	}
	 @SuppressWarnings("deprecation")
	private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        invalidateOptionsMenu();
    }
	 private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }
	 private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
	        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
            	displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
            	Log.d("EXTRA_DATA", intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
            }
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }
    private BluetoothGattCharacteristic mCharacteristic;
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;
        // Loops through available GATT Services.
	    for (BluetoothGattService gattService : gattServices) {
	        String uuid  = gattService.getUuid().toString();
	        if(BluetoothLeService.UUID_HEART_RATE_MEASUREMENT.equals(gattService.getUuid())){
	        	Log.d("gattService", uuid);
	        	if(BluetoothGattCharacteristic.PROPERTY_READ>0){
	        		List<BluetoothGattCharacteristic> gattCharacteristics =gattService.getCharacteristics();
	        		for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
	        			String charUDID = gattCharacteristic.getUuid().toString();
	        			if(charUDID.equalsIgnoreCase(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG)){
		        			Log.d("charUDID", charUDID);
	        				for(BluetoothGattDescriptor  descriptor:gattCharacteristic.getDescriptors()){
	        					String desUDID = descriptor.getUuid().toString();
	        					Log.d("desUDID", desUDID);
	        				}
	        				mCharacteristic = gattCharacteristic;
	        				mBluetoothLeService.setCharacteristicNotification(gattCharacteristic, true);
	        			}
	        		}
	        	}
	        }
	    }
	}

}
