package com.example.android.bluetoothchat;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

@SuppressLint("NewApi")
public class BLEPeripheral extends Activity implements  OnClickListener {
	private BluetoothAdapter mBluetoothAdapter;
	private BluetoothLeAdvertiser mBluetoothAdvertiser;
	private MockServerCallBack mMockServerCallBack;
	private BluetoothGattServer mGattServer ;
	private String TAG="BLEPeripheral";
	public static BluetoothDevice m_device;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_peripheral);
        Button startBtn=(Button)this.findViewById(R.id.StartBLEPeripheral);
        if(startBtn!=null){
        	startBtn.setOnClickListener(this);
        }
        Button updateBtn=(Button)this.findViewById(R.id.UpdatePeripheralNum);
        if(updateBtn!=null){
        	updateBtn.setOnClickListener(this);
        }
	}
	public void onClick(View v) {
		switch(v.getId()){
			case R.id.StartBLEPeripheral:
			{
				initBroadCast();
				break;
			}
			case R.id.UpdatePeripheralNum:
			{
				BluetoothGattService mService = mGattServer.getService(UUID.fromString(SampleGattAttributes.HEART_RATE_MEASUREMENT));
				BluetoothGattCharacteristic alc = mService.getCharacteristic(UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
				String value = "SloppyDevice";
				byte[] bytes = null;
				try {
					bytes = value.getBytes("UTF8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				alc.setValue(bytes);
				mGattServer.notifyCharacteristicChanged(m_device, alc, false);
				break;
			}
			default:{
				break;
			}
		}
	}
	private void initBroadCast(){
		final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
		mBluetoothAdapter = bluetoothManager.getAdapter();
		if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)){
			 Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
		}
		//打开蓝牙的套路
		if ((mBluetoothAdapter == null) || (!mBluetoothAdapter.isEnabled())) {
		    Toast.makeText(this, R.string.unknown_service, Toast.LENGTH_SHORT).show();
		    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		    this.startActivityForResult(enableBtIntent,0);
		}
		if (mBluetoothAdvertiser == null) {
		    mBluetoothAdvertiser = mBluetoothAdapter.getBluetoothLeAdvertiser();
		}
		mMockServerCallBack = new MockServerCallBack();
		mGattServer = bluetoothManager.openGattServer(this, mMockServerCallBack);
		try {
			mMockServerCallBack.setupServices(mGattServer);
			mBluetoothAdvertiser.startAdvertising(createAdvSettings(true, 0), createFMPAdvertiseData(),mAdvCallback);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static AdvertiseSettings createAdvSettings(boolean connectable, int timeoutMillis) {
	    AdvertiseSettings.Builder builder = new AdvertiseSettings.Builder();
	    //设置广播的模式,应该是跟功耗相关
	    builder.setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED);
	    builder.setConnectable(connectable);
	    builder.setTimeout(timeoutMillis);
	    builder.setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH);
	    return builder.build();
	}

	//设置一下FMP广播数据
	public static AdvertiseData createFMPAdvertiseData() {
	    AdvertiseData.Builder builder = new AdvertiseData.Builder();
	    builder.setIncludeDeviceName(true);
	    AdvertiseData adv = builder.build();
	    return adv;
	}

	//发送广播的回调，onStartSuccess/onStartFailure很明显的两个Callback
	private AdvertiseCallback mAdvCallback = new AdvertiseCallback() {
	    public void onStartSuccess(android.bluetooth.le.AdvertiseSettings settingsInEffect) {
	        if (settingsInEffect != null) {
	            Log.d(TAG, "onStartSuccess TxPowerLv="+ settingsInEffect.getTxPowerLevel()+ " mode=" + settingsInEffect.getMode()+ " timeout=" + settingsInEffect.getTimeout());
	        } else {
	            Log.d(TAG, "onStartSuccess, settingInEffect is null");
	        }
	    }

	    public void onStartFailure(int errorCode) {
	        Log.d(TAG, "onStartFailure errorCode=" + errorCode);
	    };
	};
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if (mBluetoothAdvertiser != null) {
		    mBluetoothAdvertiser.stopAdvertising(mAdvCallback);
		    mBluetoothAdvertiser = null;
		}

		if(mBluetoothAdapter != null){
		    mBluetoothAdapter = null;
		}

		if (mGattServer != null) {
		    mGattServer.clearServices();
		    mGattServer.close();
		}    
		super.onDestroy();
	}
	
	
}
