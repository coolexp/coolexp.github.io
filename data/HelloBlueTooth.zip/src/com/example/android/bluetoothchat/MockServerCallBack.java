package com.example.android.bluetoothchat;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import android.bluetooth.BluetoothGattServerCallback;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattService;
import android.util.Log;
@SuppressLint("NewApi")
public class MockServerCallBack extends BluetoothGattServerCallback {
	 private static final String TAG = "BleServer";
	    private byte[] mAlertLevel = new byte[] {(byte) 0x00};
	    private Activity mActivity;
	    private boolean mIsPushStatic = false;
	    private BluetoothGattServer mGattServer;
	    private BluetoothGattCharacteristic mDateChar;
	    private BluetoothDevice btClient;
	    private BluetoothGattCharacteristic mHeartRateChar;
	    private BluetoothGattCharacteristic mTemperatureChar;
	    private BluetoothGattCharacteristic mBatteryChar;
	    private BluetoothGattCharacteristic mManufacturerNameChar;
	    private BluetoothGattCharacteristic mModuleNumberChar;
	    private BluetoothGattCharacteristic mSerialNumberChar;

	    public void setupServices(BluetoothGattServer gattServer) throws InterruptedException{
	        if (gattServer == null) {
	            throw new IllegalArgumentException("gattServer is null");
	        }
	        mGattServer = gattServer;
	        // 设置一个GattService以及BluetoothGattCharacteristic 
	        { 
	            //immediate alert
	            BluetoothGattService ias = new BluetoothGattService( UUID.fromString(SampleGattAttributes.HEART_RATE_MEASUREMENT),
	                    BluetoothGattService.SERVICE_TYPE_PRIMARY);
	            //alert level char.
	            BluetoothGattCharacteristic alc = new BluetoothGattCharacteristic(
	                    UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG),
	                    BluetoothGattCharacteristic.PROPERTY_READ |BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_NOTIFY ,
	                    BluetoothGattCharacteristic.PERMISSION_READ |BluetoothGattCharacteristic.PERMISSION_WRITE);
	            alc.setValue("");
	            ias.addCharacteristic(alc);
	            if(mGattServer!=null && ias!=null)
	                mGattServer.addService(ias);
	        }
	    }

	    //当添加一个GattService成功后会回调改接口。
	    public void onServiceAdded(int status, BluetoothGattService service) {
	        if (status == BluetoothGatt.GATT_SUCCESS) {
	            Log.d(TAG, "onServiceAdded status=GATT_SUCCESS service=" + service.getUuid().toString());
	        } else {
	            Log.d(TAG, "onServiceAdded status!=GATT_SUCCESS");
	        }
	    }

	    //BLE连接状态改变后回调的接口
	    public void onConnectionStateChange(android.bluetooth.BluetoothDevice device, int status,
	            int newState) {
	        Log.d(TAG, "onConnectionStateChange status=" + status + "->" + newState);
	        BLEPeripheral.m_device = device;
	    }

	    //当有客户端来读数据时回调的接口
	    public void onCharacteristicReadRequest(android.bluetooth.BluetoothDevice device,
	            int requestId, int offset, BluetoothGattCharacteristic characteristic) {
	        Log.d(TAG, "onCharacteristicReadRequest requestId=" 
	                    + requestId + " offset=" + offset);
	        mGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset,characteristic.getValue());
	    }

	    //当有客户端来写数据时回调的接口
	    @Override
	    public void onCharacteristicWriteRequest(android.bluetooth.BluetoothDevice device,
	            int requestId, BluetoothGattCharacteristic characteristic, boolean preparedWrite,
	            boolean responseNeeded, int offset, byte[] value) {
	            mGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, null);
	            String stringValue="";
				try {
					stringValue = new String(value,"UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            Log.d(TAG, "From:"+stringValue);
	    }

	    //当有客户端来写Descriptor时回调的接口
	    @Override
	    public void onDescriptorWriteRequest (BluetoothDevice device, int requestId, BluetoothGattDescriptor descriptor, boolean preparedWrite, boolean responseNeeded, int offset, byte[] value) {

	        btClient = device;
	        Log.d(TAG, "onDescriptorWriteRequest");
	        // now tell the connected device that this was all successfull
	        mGattServer.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, value);
	    }
}
