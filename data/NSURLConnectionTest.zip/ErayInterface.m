//
//  ErayInterface.m
//  CocosGameCpp
//
//  Created by sloppy on 17/01/2017.
//
//

#import "ErayInterface.h"
static ErayInterface *instance = nil;
@implementation ErayInterface

+(ErayInterface*)getInstance {
    if (instance == nil) {
        instance = [[self alloc] init];
        [instance initializeData];
    }
    return instance;
}
-(void)initializeData{
    mData = nil;
    trustedHosts = [[NSArray alloc] initWithObjects:@"10.10.10.160", nil];
}
-(void)connnect:(NSString*)url{
    NSURL *urlForValidation = [NSURL URLWithString:url];
    NSMutableURLRequest *validationRequest = [[NSMutableURLRequest alloc] initWithURL:urlForValidation];
    [validationRequest setHTTPMethod:@"GET"];
    NSString *postStringValue = @"name=sloppy";
    [validationRequest setHTTPBody:[postStringValue dataUsingEncoding:NSUTF8StringEncoding]];
    [NSURLConnection connectionWithRequest:validationRequest delegate:self];
}
- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge {
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust])
        if ([trustedHosts containsObject:challenge.protectionSpace.host])
            [challenge.sender useCredential:[NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust] forAuthenticationChallenge:challenge];
    
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSInteger responseCode = [(NSHTTPURLResponse *)response statusCode];
    NSLog(@"response length=%lld statecode%ld", [response expectedContentLength],(long)responseCode);
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    if (mData == nil) {
        mData = [[NSMutableData alloc] initWithData:data];
    } else {
        [mData appendData:data];
    }
    NSString* aStr=[[NSString alloc ]initWithData:mData encoding:NSUTF8StringEncoding];
    NSLog(@"response connection%@",aStr);
    NSLog(@"response connection");
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    NSLog(@"connectionDidFinishLoading connection");
    if(mData!=nil){
        [mData release];
        mData = nil;
    }
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"connection didFailWithError:%@",error);
}

@end
