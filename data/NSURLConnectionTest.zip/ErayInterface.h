//
//  ErayInterface.h
//  CocosGameCpp
//
//  Created by sloppy on 17/01/2017.
//
//

#import <Foundation/Foundation.h>

@interface ErayInterface : NSObject<NSURLConnectionDataDelegate>
{
    NSArray* trustedHosts;
    NSMutableData* mData;
}

-(void)initializeData;
-(void)connnect:(NSString*)url;
+(ErayInterface *)getInstance;
@end
